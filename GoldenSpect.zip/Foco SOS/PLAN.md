# PLAN — Roadmap de Desarrollo
## CrisisRelay Mesh: Red de Malla Autónoma para Emergencias

---

## 1. MVP vs. Iteraciones Futuras

### 1.1 El "MVP Atómico" de la Fase 1 (4 funcionalidades críticas)

Aunque las 7 funcionalidades del PRD constituyen el MVP completo para un piloto operativo real, construirlas simultáneamente diluiría el esfuerzo de un equipo de 2 personas y aumentaría el riesgo de fallas físicas en la pila Bluetooth. Se prioriza un subconjunto que valide el pipeline completo de datos fuera de red (Captura GPS → Tránsito Mesh → Ingesta Pasarela → Visualización Táctica):

1. **Botón de Pánico y Alertas SOS** (transmisión `BYTES`) — mínima unidad de valor del sistema.
2. **Localización GPS Satelital Autónoma** — un SOS sin coordenadas no tiene utilidad operativa.
3. **Persistencia Local y Deduplicación Básica** (Room/SQLite) — evita tormentas de broadcast infinitas en la malla `P2P_CLUSTER`.
4. **Dashboard Táctico Minimalista** ("Faro Maestro") — interfaz visual indispensable para demostrar el éxito del sistema.

### 1.2 Nice-to-Have — Aplazados a Fase 2

- **Onboarding interactivo de permisos**: en la demo de Fase 1 se configuran manualmente los permisos y Doze en los teléfonos de prueba.
- **Hibridación bajo demanda / payloads FILE** (Wi-Fi Direct para imágenes/mapas).
- **Borrado Seguro Inmediato (Panic Wipe)**: no influye en la mecánica del flujo de comunicación inalámbrica.
- **Gestión avanzada de conexiones GATT** (cola monohilo FIFO robusta, límite 3-4 conexiones).
- **Optimización de concurrencia STA/STA** (DBS 2x2+2x2, Android 12+).

### 1.3 Nice-to-Have — Aplazados a Fase 3

- **Modo Walkie-Talkie de voz offline** (payloads `STREAM`).
- **Transacciones e-Cash offline** (comandos tipo `/pay`).
- **Licenciamiento de SDK Enterprise** para terceros (B2B).
- **Despliegue Cloud Distribuido + BFF** (migración a Cloud Run, SSO/OAuth 2.0 para operadores).
- **Row Level Security (RLS) + particionamiento de tablas** (multi-tenant en producción).
- **Integración Mapbox** como respaldo secundario de tiles.
- **Investigación de interoperabilidad con iOS** (monitoreo de Wi-Fi Aware / APIs experimentales de Apple).

---

## 2. Estructura de Hitos Secuenciales

### 2.1 Enfoque: Slices Verticales con Paralelismo por Especialización

Se descarta la división pura por capas (backend vs. móvil trabajando en aislamiento durante semanas) por ser de alto riesgo de integración en un sistema offline-first. Cada hito es un **slice vertical** (flujo funcional de extremo a extremo: Móvil → Radio → Gateway → Servidor → Dashboard), con ambos desarrolladores trabajando en paralelo dentro de su especialización, convergiendo obligatoriamente en una entrega funcional y probada al cierre.

### 2.2 Hito 1 — Persistencia Local, Captura GPS y Modelado Base

**Enfoque**: cimiento de datos en ambos extremos; un solo teléfono se geolocaliza offline y guarda una alerta localmente.

- 📱 **Aprendiz 1 (Android)**: `EmergencyAlertPacket` con validaciones nativas en `init`; localización offline vía `LocationManager.GPS_PROVIDER`/`FusedLocationProviderClient` (`PRIORITY_HIGH_ACCURACY`); Room DB + DAO con `OnConflictStrategy.IGNORE`.
- 💻 **Aprendiz 2 (Backend)**: Docker Compose (PostgreSQL+PostGIS); Flyway `V1__Initial_Schema.sql` con tablas `alerta`/`dispositivo` e índice GiST; entidades JPA + `AttributeEncryptor` (AES-256) para columnas médicas.

**Criterio de aceptación**: teléfono desconectado en Modo Avión obtiene GPS con error <10 m en campo abierto, empaqueta la alerta y la guarda en Room en <2 s.

### 2.3 Hito 2 — Comunicación de Proximidad y Enrutamiento Local

**Enfoque**: dos dispositivos físicos se descubren, se enlazan fuera de red y propagan la alerta desduplicándola en RAM.

- 📱 **Aprendiz 1**: `NearbyMeshService.kt` (anunciador/descubridor bajo `P2P_CLUSTER`); cola secuencial monohilo (`Dispatchers.IO.limitedParallelism(1)`) para conexiones GATT; lógica de `onPayloadReceived()` (extracción de UUID, deduplicación, decremento de TTL, propagación a vecinos).
- 💻 **Aprendiz 2**: pipeline backend con patrón Chain of Responsibility; endpoint `POST /api/v1/alerts/sync` con `ON CONFLICT (id) DO NOTHING`.

**Criterio de aceptación**: Teléfono A (víctima) emite SOS; Teléfono B (relevo/gateway) lo recibe por Bluetooth, lo desduplica contra Room y lo persiste. Un reenvío duplicado se detecta y aborta en milisegundos.

### 2.4 Hito 3 — Ingesta Batch Sincronizada y Dashboard Táctico E2E ("La Gran Demo")

**Enfoque**: conectar la red local offline con la central en la nube; un nodo gateway con conectividad sincroniza su cola local y actualiza el Dashboard en tiempo real.

- 📱 **Aprendiz 1**: `ConnectivityManager` detecta conexión celular/satelital → conmuta a sync de alta velocidad; batch sync de alertas `isSynced=false` vía POST; actualización de flags tras HTTP 201.
- 💻 **Aprendiz 2**: `ApplicationEventPublisher` para ingesta `/sync` idempotente → cola de WebSockets; Dashboard Vanilla JS/HTML5/CSS con Leaflet.js (`L.canvas()`), renderizado reactivo <50 ms.

**Criterio de aceptación (fin del MVP Atómico)**: el gateway envía un lote de 50 alertas pendientes; el backend las desduplica, inserta en PostgreSQL, y el mapa táctico despliega los 50 marcadores codificados por color CAP instantáneamente.

---

## 3. Criterios de Parada y Puertas de Calidad

### 3.1 Definition of Done (DoD) Transversal — aplica a todos los hitos

**1. Pruebas físicas obligatorias ("Regla del Silicio")**
- Prohibido dar por terminado un hito usando emuladores; aprobación solo en ≥2 dispositivos Android físicos.
- Validación offline de campo: toda la lógica de red debe funcionar en Modo Avión con Wi-Fi convencional apagado.
- Pruebas de tolerancia por fabricante (ej. Samsung y Xiaomi) para verificar que las políticas OEM de ahorro de energía no maten el servicio en background.

**2. Contrato de datos e interoperabilidad estricta**
- Anunciador y descubridor deben declarar exactamente la misma estrategia Nearby (`P2P_CLUSTER`).
- Revisión cruzada de la serialización (Kotlin `kotlinx.serialization`) vs. deserialización backend (Jackson/Spring) para los campos compactados (`i,t,c,b,a,u`).

**3. Gestionabilidad (trazabilidad E2E)**
- Logging estructurado obligatorio para: inicio/fin de anuncio-descubrimiento, apretón de manos aceptado, llegada del primer byte (`onPayloadReceived`), cierre/fallo de transferencia (`onPayloadTransferUpdate`), descartes por deduplicación.

**4. Ciclo de vida del dato y teardown eficiente**
- `stopDiscovery()`/`stopAdvertising()` inmediatos al consolidar conexión.
- Sin fugas de memoria; cierre de descriptores de archivo y purga de residuos ante interrupciones.

**5. Calidad del repositorio**
- Peer review obligatorio antes de merge a `main`.
- Cero warnings de linter (`detekt`/`ktlint` en Android, `checkstyle`/`SpotBugs` en Spring).
- 100% de tests unitarios e integración pasando localmente, cobertura >80% en lógica crítica (deduplicación, validación física, cifrado AES-256).

**Checklist de PR (plantilla):**
```markdown
### [DoD Transversal] - Criterios de Aceptación de Ingeniería

#### 📱 Pruebas de Capa Física y Hardware
- [ ] Verificado en ≥2 dispositivos Android físicos (emuladores descartados)
- [ ] Flujo offline funciona al 100% en Modo Avión (Wi-Fi apagado)
- [ ] Probado en distintas marcas (Samsung, Xiaomi) — Doze no suspende la app
- [ ] stopDiscovery()/stopAdvertising() se ejecutan inmediatamente al conectar

#### 🧪 Pruebas y Cobertura
- [ ] 100% de tests unitarios/integración pasan en local
- [ ] Cobertura >80% en lógica crítica

#### 📜 Trazabilidad y Calidad de Código
- [ ] Logging estructurado implementado para el ciclo Nearby completo
- [ ] Linter con cero warnings
- [ ] Revisión cruzada completada entre ambos desarrolladores
- [ ] Contrato de datos JSON validado
```

### 3.2 Mecanismos de Puertas de Calidad (3 niveles)

**A. Linters y análisis estático (pre-commit/CI)**: `detekt`+`ktlint` (Android), `Checkstyle`+`SpotBugs` (backend). CI falla ante cualquier warning sin resolver.

**B. Pruebas automatizadas (CI Pipeline — GitHub Actions/GitLab CI)**: cada PR a `main` dispara análisis estático → unitarias (JUnit5+MockK/Mockito, cobertura mínima 80%) → integración (Testcontainers con PostgreSQL+PostGIS real).

**C. Pruebas de capa física (locales, obligatorias)**: no automatizables en CI (emuladores no simulan radios concurrentes). El PR debe adjuntar reporte de prueba exitosa en ≥2 dispositivos físicos, funcionamiento en Modo Avión, y desconexión activa de radios tras conectar.

### 3.3 Human-in-the-Loop: Validación al Cierre de Cada Hito

La intervención del Arquitecto/Validador ocurre **al final de cada hito**, no solo al terminar el MVP completo — un error de diseño temprano (ej. Hito 1) degrada gravemente los hitos siguientes y puede provocar bloqueos de hardware no emulables (`GATT_ERROR 133`).

**Protocolo de auditoría por hito:**
- Alineación con el silicio/SO (ej. no procesar `FILE` antes de `Status.SUCCESS`; uso correcto de `ContentResolver` en Android Q+).
- Tolerancia a fallos y fugas (liberación de descriptores ante interrupciones físicas).
- Consistencia del contrato de datos (Kotlin ↔ Spring Boot, payload <32 KB).

Solo tras esta inspección + CI en verde se autoriza el merge a `main` y el inicio del siguiente hito.

---

## 4. Tamaño de Tareas y Modularidad

### 4.1 Enfoque Híbrido: Bloques Medianos + Descomposición Just-In-Time

**Decisión**: bloques medianos de funcionalidad como unidad de planificación en el tablero; se descomponen en micro-tareas solo cuando el desarrollador comienza a trabajar en ellos.

**Justificación**:
- Evita la parálisis por gestión de un backlog masivo de micro-tickets con solo 2 desarrolladores.
- Previene omisiones críticas de bajo nivel que ocurrirían con bloques abstractos sin descomponer.
- Trazabilidad "just-in-time": la descomposición ocurre al mover el ticket a "In Progress", alineada con el DoD transversal.

### 4.2 Ejemplo de Aplicación (Hito 1)

**Nivel 1 — Bloque mediano (tablero general):**
> `Móvil: Persistencia de Alertas en Room y Lógica de Deduplicación` — Asignado a Aprendiz 1.

**Nivel 2 — Micro-tareas (al mover a "In Progress"):**
- [ ] Diseñar `EmergencyAlertPacket` con validaciones en `init` (lat/lng).
- [ ] Crear `ProcessedPacketEntity` con índice único B-Tree sobre UUID `"i"`.
- [ ] Configurar DAO con `OnConflictStrategy.IGNORE`.
- [ ] Query de cola pendiente de sincronizar (`isSynced = false`).
- [ ] Tests unitarios JUnit5+MockK para descarte de duplicados.
- [ ] DoD: validar en dispositivo físico vía Logcat, escritura correcta de GPS en Modo Avión.

---

## 5. Despliegue y Feedback Externo

### 5.1 Estrategia Híbrida: Demos Presenciales + VPS Público Temporal

**1. Demos presenciales controladas (obligatorias)**
- Hardware real: ≥2 dispositivos físicos Android (emuladores no soportan Bluetooth/Wi-Fi Direct concurrente).
- Simulación en campo abierto o edificio grande: alejar dispositivos más allá del rango de ~100 m de Nearby Connections para demostrar message hopping y store-and-forward.
- Laptop como central local: Dashboard en Docker Compose, conectado junto a los móviles a un router/hotspot Wi-Fi local (sin necesidad de internet).

**2. Despliegue remoto del Dashboard (VPS público temporal)**
- Para stakeholders externos (inversionistas, directores de agencias) no presentes en el simulacro.
- Nodos gateway híbridos: al detectar conectividad celular/internet, el móvil se enlaza dinámicamente al VPS público y transmite telemetría y topología de la red local.
- Visualización remota del "Gemelo Digital": cualquier tercero con la URL pública puede ver el mapa de la malla de supervivencia en tiempo real sin estar físicamente presente.

### 5.2 Flujo Recomendado

1. **Fase temprana**: pruebas presenciales internas del equipo (2-3 dispositivos + laptop con Docker local) para pulir negociación de sockets y envío de payloads.
2. **Fase intermedia (feedback de stakeholders)**: VPS público activo; simulacro presencial con rescatistas en campo (celulares offline) mientras patrocinadores/inversionistas remotos observan la topología dibujarse en vivo en el Dashboard del VPS.

---

*Documento generado a partir de la Fase de Entrevista Quirúrgica — Sección 3 del proceso PRD/TRD/PLAN/User Flow.*
