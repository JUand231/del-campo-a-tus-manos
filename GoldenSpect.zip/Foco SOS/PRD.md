# PRD — Product Requirements Document
## CrisisRelay Mesh: Red de Malla Autónoma para Emergencias

---

## 1. El Problema y los Objetivos de Éxito

### 1.1 Problema
Durante emergencias masivas (sismos, huracanes, conflictos armados, colapsos de infraestructura), las redes de telefonía celular e internet colapsan por completo. Las víctimas atrapadas no tienen forma de reportar su ubicación ni su estado a los equipos de rescate, y estos no tienen forma de localizarlas ni priorizarlas.

### 1.2 Propuesta de Valor
Garantizar una línea de vida digital y localización en tiempo real para víctimas y rescatistas en zonas de catástrofe cuando las redes de telefonía celular e internet han colapsado por completo, transformando los teléfonos inteligentes de la propia comunidad en una red de malla autónoma, resiliente, segura y de ultra bajo consumo de batería.

### 1.3 KPIs de Éxito

**KPIs Técnicos de Red (Rendimiento y Eficiencia de la Malla)**

| Métrica | Objetivo MVP | Referencia protocolos tradicionales |
|---|---|---|
| Packet Delivery Ratio (PDR) | 92.5% en alta densidad de nodos | 80.1% – 85.3% |
| Latencia de alertas críticas (triage) | ~120 ms | 185 – 210 ms |
| Throughput local (control + triage) | ~1,120 Kbps | — |
| Consumo energético por nodo | Reducción del 30% (≈5.1 J/nodo) | — |
| Consumo BLE (canal de control) | ≈0.5% – 1% por hora | — |
| Consumo Nearby Connections (sync masivo) | ≈5.5% – 6% por hora, solo en ráfagas | — |
| Convergencia de rutas ante caída de enlaces | Medido y reportado | — |
| Hop Count óptimo | Minimizado por algoritmo de enrutamiento | — |

**KPIs de Adopción y Sostenibilidad de Negocio**

- **Escala de descargas orgánicas**: crecimiento impulsado por relevancia en catástrofes reales, sin marketing pagado (referencia: Bridgefy, +12M descargas orgánicas tras desastres).
- **Sostenibilidad financiera (modelo B2B)**: licenciamiento de SDK a terceros para financiar el acceso gratuito de supervivencia al usuario final.
- **Clientes Enterprise**: meta inicial de ~10 clientes corporativos con licencias activas.
- **Alianzas institucionales**: integración con sistemas de gestión de crisis municipales (FEMA o equivalentes) y agencias como la ONU.
- **Satisfacción (App Store Rating)**: calificación saludable sostenida mediante onboarding que gestione expectativas sobre la necesidad de masa crítica de nodos cercanos.

---

## 2. Usuarios, Roles y Permisos

### 2.1 Usuarios Finales

1. **Poblaciones vulnerables y familias en zonas de desastre natural** (terremotos, huracanes, colapsos eléctricos).
2. **Asistentes a eventos masivos** (festivales, estadios, campus, casinos) con saturación de red por exceso de accesos simultáneos.
3. **Activistas, manifestantes y periodistas** que requieren comunicación resistente a censura, bloqueos de internet y vigilancia.
4. **Personal médico, rescatistas y cuerpos de seguridad** (capa de respuesta): EMTs, paramédicos, bomberos, policía, seguridad privada.
5. **Comunidades en zonas de guerra o crisis humanitarias severas** (incluye uso por agencias como la ONU).
6. **Poblaciones rurales o marginadas** sin infraestructura de telecomunicaciones permanente.

### 2.2 Roles y Permisos (RBAC)

**Rol: Víctima / Usuario Afectado**
- Acceso: offline, local, anónimo (sin credenciales).
- Lectura: su propia geolocalización offline; confirmaciones de estado de rescatistas.
- Escritura: perfil médico básico local; botón de pánico (distress message); metadatos de triage (grupo sanguíneo, urgencia) vía payloads `BYTES`.

**Rol: Rescatista / Personal de Campo**
- Acceso: híbrido (offline en malla vía Nearby Connections + online como puente celular/satelital).
- Lectura: alertas de triage en radio ~100 m; visualización táctica de coordenadas en mapa.
- Escritura: cambio de estado de alertas ("atendido", "en camino"); retransmisión store-and-forward; sincronización batch al backend al detectar señal.

**Rol: Coordinador / Administrador de Crisis**
- Acceso: online completo, Dashboard Web autenticado.
- Lectura: telemetría agregada de la malla; histórico de estados de rescate; mapa táctico de triage.
- Escritura: gestión global de incidentes; despacho de brigadas; revocación/cierre de alertas; broadcasts masivos vía nodos puente.

**Nivel: Cliente Enterprise / Integración Organizacional (SDK)**
- Acceso: licenciamiento del protocolo offline (ONU en zonas de conflicto, administradores de recintos cerrados).
- Permisos: despliegue de beacons dedicados; consumo programático de APIs de sincronización ad-hoc.

---

## 3. Funcionalidades y Criterios de Aceptación

### 3.1 Botón de Pánico y Alertas SOS Offline
**Funcionalidad**: activación inmediata de alerta de auxilio local; payload `BYTES` (<32 KB) con UUID, timestamp, urgencia CAP, tipo de sangre; representación visual de estado en mapa (nueva / aceptada / en atención).

**Criterio de aceptación**: al presionar el botón, la app empaqueta el payload `BYTES` (<32 KB) con UUID (i), timestamp UNIX (t), GPS [lat,lng] (c), grupo sanguíneo (b), alergias (a), urgencia CAP (u), y lo encola en la cola FIFO del servicio en segundo plano en <2 s incluso en Modo Avión. Si falla el envío inicial, reintenta `startAdvertising` bajo `P2P_CLUSTER` cada 15 s hasta consolidar conexión y entrega simétrica con un nodo cercano, momento en el cual suspende las retransmisiones.

### 3.2 Mensajería de Supervivencia y Canales Híbridos
**Funcionalidad**: texto, notas de voz, imágenes, coordenadas P2P; modo walkie-talkie (streaming de voz); canal de control persistente en BLE con activación temporal de Wi-Fi Direct para archivos pesados; transferencias e-Cash offline.

**Criterio de aceptación**:
- Texto/e-Cash: payloads `BYTES` (<32 KB) por Bluetooth, cargados en RAM para despacho instantáneo.
- Voz: canal `STREAM` con hilo de fondo dedicado; timeout de lectura de 5 s para evitar bloqueo de buffer.
- Archivos: `BYTES` previo con ID/nombre → canal `FILE` vía Wi-Fi Direct → confirmación solo con `onPayloadTransferUpdate` = `Status.SUCCESS` → en Android Q+ mover archivo vía `ContentResolver`/URI → apagar Wi-Fi Direct inmediatamente tras completar.

### 3.3 Localización y Captura GPS Satelital Autónoma
**Funcionalidad**: geolocalización pasiva sin red, incluso en Modo Avión.

**Criterio de aceptación**: forzar `Priority.PRIORITY_HIGH_ACCURACY` (FusedLocationProviderClient) o `LocationManager.GPS_PROVIDER` directo. Cold Start: Fix estable en 12–15 min (50 bps). Warm/Hot Start: Fix con margen de error 1–10 m en 5–60 s. Batching de ubicación pasiva vía `setMaxUpdateDelayMillis` al doble/triple del intervalo, para no despertar el procesador repetidamente.

### 3.4 Enrutamiento Inteligente y Sincronización en Lote
**Funcionalidad**: store-and-forward asíncrono; deduplicación por UUID; TTL de propagación; sincronización pasarela (gateway) al recuperar señal.

**Criterio de aceptación**:
- Deduplicación: `onPayloadReceived` extrae UUID (i) y lo verifica contra Room; si existe, se descarta y se detiene su retransmisión.
- Propagación: si TTL > 1, decrementar, persistir en Room, retransmitir a todos los nodos adyacentes activos.
- Sync pasarela: al detectar conectividad, conmutar a `HighSpeedSyncStrategy`, leer lote de Room en hilo secundario, enviar `POST` único idempotente a `/api/v1/alerts/sync`. Backend inserta con `ON CONFLICT (id) DO NOTHING`.

### 3.5 Onboarding Interactivo y Ciclo de Trabajo Adaptativo
**Funcionalidad**: pantallas guiadas para permisos y exclusión de batería; duty cycling; cifrado extremo a extremo (protocolo Signal).

**Criterio de aceptación**:
- Onboarding solicita `ACCESS_FINE_LOCATION`, `BLUETOOTH_SCAN`, `BLUETOOTH_ADVERTISE`, `BLUETOOTH_CONNECT`; dispara intent de exclusión de Doze/optimizadores OEM.
- Duty cycling: radios suspendidos en background; despertar coordinado 3–5 min cada hora para intercambiar ráfagas de Room.
- Todas las operaciones Nearby (anuncio, descubrimiento, conexión) enrutadas secuencialmente vía canal Kotlin + corrutina `Dispatchers.IO.limitedParallelism(1)`, timeout de 5 s por operación.

### 3.6 Dashboard Táctico de Comando (Gemelo Digital)
**Funcionalidad**: consolidación de telemetría vía WebSockets; mapeo táctico con Leaflet.js/OpenStreetMap.

**Criterio de aceptación**: al recibir alerta, Spring Boot inserta el registro y despacha el payload JSON vía WebSockets en <100 ms. El Dashboard valida en `onmessage` que el UUID no esté ya renderizado (caché en memoria), pinta un `L.circleMarker` (Canvas de Leaflet.js) con color según prioridad CAP en <50 ms, soportando >1,000 marcadores simultáneos sin caída de frames.

### 3.7 Borrado Seguro Inmediato (Panic Wipe)
**Funcionalidad**: autodestrucción de datos sensibles mediante triple toque en el logo.

**Criterio de aceptación**: tres toques consecutivos al logo en ≤1.5 s disparan tarea asíncrona irrevocable que purga claves criptográficas de RAM, ejecuta `database.clearAllTables()`, borra Shared Preferences, y finaliza el proceso en segundo plano en <500 ms. El borrado de claves en RAM debe priorizarse antes que el borrado de tablas Room, garantizando irreversibilidad forense incluso ante interrupción abrupta del sistema.

---

## 4. Límites, Restricciones y Exclusiones

### 4.1 Compatibilidad de Plataformas
- SDK mínimo: Android 21 (5.0 Lollipop); Target SDK 33+.
- Pruebas obligatorias en ≥2 dispositivos físicos Android; **prohibido** el uso de emuladores (no soportan concurrencia real de Bluetooth/Wi-Fi Direct).
- **Interoperabilidad Android–iOS**: técnicamente imposible en campo abierto (Apple bloquea el acceso físico de radio de AWDL/AirDrop). Única vía: ambos dispositivos conectados a una LAN Wi-Fi común con router/AP externo.

### 4.2 Límites Físicos de Payloads y Concurrencia
- Payloads `BYTES`: máximo 32 KB, cargados íntegramente en RAM.
- Bluetooth Classic: máximo 3–4 conexiones GATT concurrentes reales (límite teórico de 7 no alcanzable).
- Wi-Fi Hotspot local: máximo empírico de 10 conexiones simultáneas (límite práctico de Spokes en `P2P_STAR`).
- Banda Dual Simultánea (DBS) 2x2+2x2 requerida en producción (evitar antena única 1x1+1x1). Si se usa MCC (conmutación por tiempo): ciclo 70% datos usuario / 30% interfaz Nearby.

### 4.3 Persistencia y Scoped Storage
- Android Q+ (API 29+): **prohibido** acceso directo a archivos vía `payload.asFile().asJavaFile()`. Obligatorio usar URI del payload + `ContentResolver` en hilos secundarios.

### 4.4 Gestión de Permisos por Versión de Android
- Android 6–11 (API 23–30): `BLUETOOTH`, `BLUETOOTH_ADMIN`, `ACCESS_WIFI_STATE`, `CHANGE_WIFI_STATE` + runtime `ACCESS_FINE_LOCATION`/`ACCESS_COARSE_LOCATION`.
- Android 12–14 (API 31–34): `BLUETOOTH_SCAN`, `BLUETOOTH_ADVERTISE`, `BLUETOOTH_CONNECT`; desde Android 13, `NEARBY_WIFI_DEVICES`.

### 4.5 Restricciones de Energía, CPU y Throttling
- Obligatorio encauzar todas las interacciones GATT en cola FIFO monohilo (`limitedParallelism(1)`) con timeout de 5 s, para evitar `GATT_ERROR 133`.
- Detener activamente `stopDiscovery()`/`stopAdvertising()` al consolidar conexión simétrica.
- **Prohibido** disparar más de 5 inicios de escaneo BLE en 30 s en background (throttling silencioso de Android 9+); usar `PendingIntent` con `ScanFilter` en su lugar.

### 4.6 Recolección de Datos de Google
- La integración de Nearby Connections vía Google Play Services recolecta automáticamente telemetría de uso y del dispositivo. Requisito no funcional: informar al usuario que puede desactivarlo en Ajustes > Google > Uso y diagnóstico.

### 4.7 Restricciones Explícitas de la API Nearby Connections
1. **Prohibido alternar dinámicamente estrategias** (`P2P_CLUSTER` ↔ `P2P_STAR`) con sockets/conexiones activas; anunciador y descubridor deben correr la misma estrategia.
2. **Prohibido** el acceso directo a archivos en disco vía Java tradicional en Android Q+ (ver 4.3).
3. **Interoperabilidad P2P directa con iOS bloqueada** físicamente (ver 4.1).
4. **No hay soporte nativo de multi-hop**: toda la lógica de enrutamiento, retransmisión y deduplicación debe programarse en el espacio de usuario de la app; no debe asumirse que la API la resuelve.

---

## 5. Expectativas de Pruebas y Comportamientos Críticos

### 5.1 Ciclo de Vida del Payload e Interrupción de Transferencias
- **Lectura prematura**: prohibido procesar un payload `FILE`/`STREAM` dentro de `onPayloadReceived()`; debe esperarse `onPayloadTransferUpdate()` con `Status.SUCCESS`.
- **Caída de enlace a mitad de transferencia**: capturar `Status.FAILURE`/`Status.CANCELED`, cerrar `ParcelFileDescriptor` inmediatamente, purgar archivos parciales temporales.
- **Scoped Storage (Android Q+)**: validar que el sistema use `asUri()` + `ContentResolver`, nunca `asFile().asJavaFile()`.

### 5.2 Tolerancia a Fallos en la Malla, DTN y Ciclo de Trabajo
- **Caída de nodo intermedio**: la malla debe auto-sanarse, recalcular vecindad, usar Reverse Path Forwarding o vector de distancias, propagar por rutas alternativas sin pérdida ni duplicados.
- **Colisión de UUIDs**: si dos nodos puente transmiten la misma alerta a un receptor común, Room debe marcar la segunda como duplicada y cortar su retransmisión (short-circuit).
- **Sincronización con duty cycling extremo**: Room actúa como búfer DTN persistente; al despertar en la ventana de 3–5 min, negociar transferencia de la cola acumulada antes de re-suspender radios.

### 5.3 Estabilidad de la Pila Bluetooth y Restricciones del SO
- **Throttling de escaneo (Android 9+)**: prohibido bucles rápidos de encendido/apagado; validar uso de `ScanFilter`/`PendingIntent`.
- **Saturación GATT (Error 133)**: forzar ráfagas de 5 conexiones concurrentes en pruebas; verificar encolado monohilo, cierre de sockets fallidos, respeto del límite de 3–4 conexiones activas.
- **Conmutación dual inestable (MCC)**: verificar tolerancia y mantenimiento del ciclo 70/30 sin desconexión de sesión.

### 5.4 Ingesta de Datos e Idempotencia con Backend Caído
- **Backend caído (503/504/TCP down)**: prohibido purgar Room local; retener el lote y reintentar con backoff exponencial; marcar como sincronizado solo tras HTTP 200/201.
- **Ráfagas concurrentes duplicadas**: probar 100 ráfagas duplicadas de la misma alerta desde múltiples gateways; verificar que la BD central contenga exactamente un registro (`ON CONFLICT (id) DO NOTHING`) y que el WebSocket emita una única notificación.

### 5.5 Integridad del Protocolo de Borrado Físico (Panic Wipe)
- **Interrupción a mitad de wipe**: el diseño debe garantizar que el borrado de claves de cifrado en RAM ocurra antes que el borrado de tablas Room, de modo que una interrupción abrupta (apagado físico, extracción de batería) deje los datos remanentes permanentemente inaccesibles y cifrados de forma irreversible.

---

*Documento generado a partir de la Fase de Entrevista Quirúrgica — Sección 1 del proceso PRD/TRD/PLAN/User Flow.*
