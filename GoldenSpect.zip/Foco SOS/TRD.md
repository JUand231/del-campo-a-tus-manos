# TRD — Technical Requirements Document
## CrisisRelay Mesh: Red de Malla Autónoma para Emergencias

---

## 1. Stack Tecnológico y Arquitectura de Software

### 1.1 Stack por Componente

**Componente Móvil — Estricto y Definitivo: Android Nativo (Kotlin)**
No se permiten frameworks híbridos (React Native, Flutter, MAUI) en el MVP. Razones técnicas:
- Gestión de hilos/Bluetooth: la pila BLE de Android exige serialización monohilo con colas FIFO y timeouts de 5 s; wrappers híbridos provocan colisiones que corrompen el transceptor (`GATT_ERROR 133`).
- Geolocalización autónoma: requiere `LocationManager.GPS_PROVIDER` directo, evadiendo `FusedLocationProviderClient` (que falla offline).
- Scoped Storage (Android Q+): manejo de URIs vía `ContentResolver`, no soportado de forma confiable por librerías multiplataforma.

**Componente Backend — Semi-Estricto: Spring Boot / Java-Kotlin Enterprise**
Estándar de la industria para implementar con rigor los patrones de diseño requeridos (Chain of Responsibility, State, Observer, Strategy).

**Motor de Base de Datos**: PostgreSQL + PostGIS (definitivo) — ver Sección 2.

**Dashboard Web — Flexible, seleccionable:**
- **Opción 1 (predeterminada/offline)**: Vanilla HTML5/CSS3/JS estático, servido localmente por Nginx en entornos tácticos desconectados (laptop de campaña, Raspberry Pi). Leaflet.js sin sobrecarga de DOM virtual.
- **Opción 2 (SPA escalable)**: React.js/Vue.js con React-Leaflet, para centros de mando metropolitanos/nube con gestión de estado reactivo.
- **Requisito obligatorio (ambas opciones)**: Leaflet.js + OpenStreetMap, renderizador Canvas (`L.canvas()`) para soportar >1,000 marcadores concurrentes de triage.

### 1.2 Arquitectura General: Monolito Modular con Eventos Internos

**Decisión**: Monolito modular (Spring Boot, un único `.jar`) con diseño interno orientado a eventos locales vía `ApplicationEventPublisher`/`@EventListener` (patrón "Event-Driven sin infraestructura de mensajería").

**Justificación**:
- Consumo mínimo de RAM/CPU, viable en hardware limitado (laptop de campaña, Raspberry Pi) sin acceso a la nube; microservicios o Kafka/RabbitMQ son inviables en ese contexto.
- Equipo de 2 personas: evita sobrecarga cognitiva de orquestación distribuida; permite compartir Domain Entities y un único pipeline de CI.
- Los eventos internos en memoria permiten que el endpoint `/sync` responda en milisegundos (HTTP 201) delegando triage, clasificación y despacho de WebSockets a hilos secundarios desacoplados.

**Estructura de paquetes** (dependencias unidireccionales, preparada para migración futura a microservicios si la escala lo exige):

```
es.crisisrelay.backend
├── alerts       <- Dominio core de alertas, triage y persistencia (JPA/Hibernate)
├── sync         <- Gateway de sincronización batch idempotente de dispositivos móviles
├── telemetry    <- WebSockets, emisión en tiempo real hacia el mapa Leaflet
├── security     <- Filtros JWT ligeros para acceso de operadores del Dashboard
└── shared       <- Modelos comunes e integraciones criptográficas (firmas/hashes)
```

---

## 2. Modelo de Datos y Persistencia

### 2.1 Motor de Base de Datos

**Definitivo**: PostgreSQL + extensión PostGIS.
- Índices espaciales GiST sobre coordenadas → consultas de proximidad ultrarrápidas.
- Geofencing nativo (polígonos de zonas de riesgo cruzados con ubicación de alertas).

**Alternativa documentada**: MySQL/MariaDB, para entornos de despliegue offline donde compilar dependencias nativas de PostGIS (GEOS, GDAL, PROJ) sea un cuello de botella. Soporte geoespacial básico vía `ST_Point`/`ST_Distance`.

> Nota: no existía un ERD previo en la documentación fuente (esta se centraba en persistencia local SQLite/Room). El modelo de datos del backend fue derivado durante esta entrevista.

### 2.2 Diagrama Entidad-Relación (Modelo Lógico)

**Entidades principales:**

- **`Dispositivo` / Nodo** — `id` (VARCHAR(48), hash SHA-256 de MAC/UUID de instalación), `tipo` (ENUM: Víctima/Rescatista/Gateway), `bateria_porcentaje`, `ultima_conexion`.
- **`Usuario` / Operador** — `id` (BIGINT), `username` (único), `password_hash`, `rol` (ENUM: COORDINADOR/ADMIN).
- **`Alerta`** (entidad central) — `id` (VARCHAR(32), payload `i`), `creado_at` (de `t`), `ubicacion` (`GEOMETRY(POINT,4326)`, de `c`), `grupo_sanguineo` (de `b`, cifrado), `alergias` (de `a`, cifrado), `urgencia_cap` (de `u`), `estado_rescate` (ENUM patrón State: RECIBIDA → RESCATISTAS_ASIGNADOS → EN_CAMINO → ATENDIDA → CERRADA), `ttl`, FK `dispositivo_origen_id`.
- **`LoteSincronizacion`** (SyncBatch) — `id` (UUID), FK `pasarela_id`, `recibido_at`, `total_registros`.
- **`LoteAlerta`** — tabla de unión N:M entre `LoteSincronizacion` y `Alerta` (una alerta puede ser transportada por múltiples gateways; se audita trazabilidad y latencia real de sincronización).
- **`AsignacionRescate`** — `id` (BIGINT), FK `alerta_id` (único), FK `rescatista_id`, FK `operador_id`, `asignado_at`, `resuelto_at` (nullable — su asignación dispara notificación WebSocket a la víctima para apagar radios).

### 2.3 Entidad Local Compacta (Cliente Android — Room)

```kotlin
@Entity(tableName = "local_alerts")
data class ProcessedPacketEntity(
    @PrimaryKey val id: String,          // "i"
    val timestamp: Long,                 // "t"
    val latitude: Double,                // "c"[0]
    val longitude: Double,               // "c"[1]
    val bloodType: String,               // "b"
    val allergies: String,               // "a"
    val CAPUrgency: Int,                 // "u"
    val isSynced: Boolean = false,
    val ttl: Int
)

@Dao
interface AlertDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAlertIfNew(alert: ProcessedPacketEntity): Long

    @Query("SELECT * FROM local_alerts WHERE isSynced = 0")
    suspend fun getPendingSyncBatch(): List<ProcessedPacketEntity>
}
```
Sin relaciones foráneas complejas, para evitar latencias de escritura en SQLite.

### 2.4 Políticas de Seguridad y Migraciones

**Obligatorias en el MVP:**

- **Índices espaciales GiST/PostGIS**:
  ```sql
  CREATE INDEX idx_alerta_ubicacion ON alerta USING gist(ubicacion);
  ```
- **Migraciones versionadas con Flyway**: sincronización automática del esquema físico con las entidades JPA; trazabilidad de la evolución del dominio; evita colisiones en Git en equipo de 2 personas.
- **Cifrado a nivel de columna (AES-256)** para `grupo_sanguineo` y `alergias` en reposo, vía `@Convert(converter = AttributeEncryptor.class)`. Descifrado solo en RAM del servidor, para operador autenticado.

**Documentadas para fase de producción/escalabilidad:**

- **Row Level Security (RLS)**: aislamiento de datos por organización cuando múltiples clientes Enterprise (ej. Cruz Roja, Defensa Civil) compartan la misma base de datos.
- **Particionamiento de tablas por fecha/incidente**: las alertas pierden validez operativa tras 72–96 h; particionar permite archivar/purgar con `DROP PARTITION` manteniendo la BD ligera.

**Migración inicial de referencia (`V1__Initial_Schema.sql`):**

```sql
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE dispositivo (
    id VARCHAR(48) PRIMARY KEY,
    tipo VARCHAR(20) NOT NULL,
    bateria_porcentaje INT,
    ultima_conexion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE alerta (
    id VARCHAR(32) PRIMARY KEY,
    creado_at TIMESTAMP NOT NULL,
    ubicacion GEOMETRY(Point, 4326) NOT NULL,
    grupo_sanguineo VARCHAR(255) NOT NULL, -- AES-256 encrypted string
    alergias VARCHAR(255) NOT NULL,        -- AES-256 encrypted string
    urgencia_cap INT NOT NULL,
    estado_rescate VARCHAR(30) NOT NULL,
    ttl INT NOT NULL,
    dispositivo_origen_id VARCHAR(48) REFERENCES dispositivo(id)
);

CREATE INDEX idx_alerta_ubicacion ON alerta USING gist(ubicacion);
CREATE INDEX idx_alerta_estado_urgencia ON alerta (estado_rescate, urgencia_cap);
```

---

## 3. Integración de APIs y Seguridad

### 3.1 Integraciones de Terceros: Ninguna en el MVP (sistema air-gapped)

**Decisión definitiva**: el MVP es 100% autónomo. No se integra Stripe, OAuth/SSO externo, Mapbox ni Firebase Cloud Messaging.

**Justificación**:
- Nearby Connections opera de forma P2P local sin infraestructura intermedia (a diferencia de Nearby Messages, que sí requiere API keys de Google e internet).
- Cualquier dependencia en la nube (SSO, tiles externos) inutilizaría el Dashboard si se despliega en una zona de desastre sin conectividad.

**Resolución autosuficiente dentro del monolito**:
- **Autenticación**: Spring Security + JWT firmados localmente con clave secreta preconfigurada (sin SSO externo).
- **Mapas**: tiles de OpenStreetMap pre-renderizados y almacenados localmente en disco.
- **Notificaciones**: WebSockets persistentes en LAN, expuestos directamente por el monolito Spring Boot (sin FCM).

**Documentado como roadmap de escalabilidad futura (prohibido en el MVP)**: OAuth 2.0/SSO (Google Workspace, Azure AD) y APIs de mapas adicionales (Mapbox), para despliegues de centros de mando metropolitanos en la nube.

### 3.2 Protección de Credenciales y Secretos

- **Sin API keys de terceros que proteger en el MVP** (consecuencia directa de 3.1).
- **Variables de entorno cifradas** para los tres secretos sensibles del monolito: credenciales de PostgreSQL, clave simétrica AES-256 (cifrado de columnas médicas), firma secreta de JWT. Prohibido hardcodearlos en `application.properties` o subirlos a Git; se inyectan en el entorno del sistema operativo local al levantar el `.jar`/contenedor.
- **JWT de corta duración (máx. 15 minutos)** para sesiones de operadores del Dashboard, con credenciales locales cifradas (BCrypt) en PostgreSQL. Mitiga el riesgo de terminales robadas/abandonadas en campo.

---

## 4. Estrategia de Pruebas y Robustez

### 4.1 Cobertura de Pruebas — Completa, todas obligatorias

| Tipo | Herramientas | Alcance |
|---|---|---|
| **Unitarias** | MockK (Kotlin/Android), JUnit5 + Mockito (Spring Boot) | Máquina de estados de red, decremento de TTL, descarte idempotente de duplicados por UUID (móvil); pipeline de triage, serialización JSON táctico, cifrado AES-256 (backend) |
| **Integración** | Spring Boot Test + Testcontainers (PostgreSQL+PostGIS real, no H2) | Indexación GiST, consultas de proximidad espacial bajo concurrencia |
| **E2E en dispositivos físicos** | Espresso + mínimo 2 Android reales | Emparejamiento, intercambio de llaves, transmisión bidireccional (emuladores no soportan BLE/Wi-Fi Direct concurrente) |
| **Carga/estrés** | Gatling / JMeter | 100+ peticiones concurrentes a `/sync`; idempotencia (`ON CONFLICT DO NOTHING`); latencia WebSocket <100 ms bajo carga |
| **Resiliencia de red** | Simulación en campo | Corte a mitad de transferencia FILE/STREAM (`Status.FAILURE`, liberación de descriptor, purga de residuos); caída de nodos relevo y recálculo de vector de distancias |

### 4.2 Esquemas de Validación de Datos

- **Cliente Android**: `kotlinx.serialization` + validación manual en bloque `init` de la `data class` (sin JSON Schema, para minimizar overhead de APK/CPU en el dispositivo de la víctima).
- **Ambos extremos — validación de rangos físicos**: latitud [-90,90], longitud [-180,180], `urgencia_cap` en [0,3], TTL ≥ 0.
- **Backend**: Bean Validation/JSR-380 (`@NotNull`, `@Size(min=32,max=32)` para UUID, `@Min(0)`/`@Max(3)` para CAP) como última línea de defensa declarativa antes de persistencia, devolviendo HTTP 400 ante datos corruptos.

**Referencia de validación en el cliente:**
```kotlin
@Serializable
data class EmergencyAlertPacket(
    val i: String, val t: Long, val c: List<Double>,
    val b: String, val a: String, val u: Int, val ttl: Int
) {
    init {
        require(i.length == 32) { "El UUID 'i' debe tener exactamente 32 caracteres." }
        require(c.size == 2) { "El campo 'c' debe contener [latitud, longitud]." }
        val lat = c[0]; val lng = c[1]
        require(lat in -90.0..90.0) { "Latitud inválida: $lat." }
        require(lng in -180.0..180.0) { "Longitud inválida: $lng." }
        require(u in 0..3) { "Urgencia CAP fuera de rango (0-3): $u" }
        require(ttl >= 0) { "El TTL no puede ser negativo: $ttl" }
    }
}
```

---

## 5. Despliegue, DevOps y Observabilidad

### 5.1 Estrategia de Despliegue: Híbrido

**MVP (obligatorio)**: **VPS/hardware local con Docker Compose**. Empaqueta Spring Boot + PostgreSQL/PostGIS + Nginx (tiles OSM locales) en contenedores, evitando compilar dependencias nativas de PostGIS (GEOS, GDAL, PROJ) en bare-metal. Un solo comando (`docker-compose up -d`) para levantar la central en laptop táctica o Raspberry Pi conectada a un router local de emergencia.

**Roadmap de escalabilidad (documentado)**: migración del mismo monolito contenerizado a **Cloud Run** u otras instancias gestionadas, sin reescritura de código, para centros de mando metropolitanos con conectividad estable e ingesta multi-zona.

### 5.2 Telemetría y Observabilidad

**Obligatorias en el MVP:**

- **Logs estructurados (JSON)** con Logback/SLF4J: auditoría de alertas descartadas por deduplicación, variaciones de TTL, ráfagas concurrentes en `/sync` — principio de gestionabilidad/trazabilidad de la red.
- **Monitoreo del sistema (Spring Boot Actuator + Micrometer)**: health checks del monolito, saturación de buffers/colas, prevención de bloqueos en interfaces asíncronas — crítico en hardware táctico de recursos limitados.
- **Métricas de batería y estado de la malla**: umbral crítico de exclusión de nodos relevo por debajo del 15% de batería (`E_res`); RSSI para predecir desconexiones; RAM libre/almacenamiento interno para prevenir OOM en dispositivos de retransmisión. El Dashboard actúa como gemelo digital vivo de la salud energética de la red.

**Resolución de caché**: **prohibido** desplegar Redis independiente en el MVP (sobrecarga de RAM/CPU en hardware de campaña). Se usa **caché in-memory Caffeine** vía `@Cacheable` de Spring, integrada en el propio monolito, con latencias de lectura en microsegundos sin contenedores adicionales.

---

*Documento generado a partir de la Fase de Entrevista Quirúrgica — Sección 2 del proceso PRD/TRD/PLAN/User Flow.*
