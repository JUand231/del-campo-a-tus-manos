# User Flow — Flujo de Navegación
## CrisisRelay Mesh: Red de Malla Autónoma para Emergencias

---

## 1. Punto de Partida y Estado Inicial

### 1.1 Arquitectura de Distribución

- **Una sola app móvil** (víctima/rescatista), que cambia dinámicamente de interfaz y capacidades según el rol seleccionado en el onboarding. Justificación: en zonas sin internet no es viable distribuir dos APKs; una sola app permite compartir el mismo core de red (Nearby Connections) y facilita la distribución local de teléfono a teléfono vía malla.
- **Dashboard web independiente**, exclusivo para el Coordinador, desplegado en VPS público temporal.

### 1.2 Entry Point: Onboarding Obligatorio (3 pasos)

No es posible abrir la app directamente en estado "Listo para SOS" — Android exige una fase de inicialización previa:

1. **Concesión de permisos en tiempo de ejecución**: `BLUETOOTH_SCAN`, `BLUETOOTH_ADVERTISE`, `BLUETOOTH_CONNECT` (Android 12+); `ACCESS_FINE_LOCATION` (requerido por el SO para escaneo BLE/Wi-Fi, aunque la app no use GPS con fines de tracking externo).
2. **Exclusión de optimización de batería** (Doze + personalizaciones OEM de Samsung/Xiaomi/OnePlus), con pantallas explicativas guiadas.
3. **Definición de identidad local (alias de red)**: generación de un identificador/alias aleatorio, almacenado cifrado localmente, para el `localUsername` de Nearby Connections.

Al completar el onboarding, la app transiciona automáticamente al estado **"Listo para SOS"** — sin selección técnica compleja de rol para el usuario víctima. La app activa `P2P_CLUSTER` en modo ultra bajo consumo (balizas BLE) y queda en escucha pasiva/anuncio intermitente.

### 1.3 Diferencias por Perfil al Abrir la App

| Perfil | Interfaz | Acceso |
|---|---|---|
| **Víctima** | App móvil, modo anónimo offline | Botón SOS central; chat de supervivencia; indicador de estado de malla; wipe de pánico |
| **Rescatista** | App móvil, modo híbrido (activado con PIN de agencia offline) | Mapa de situación offline; lista dinámica de alertas por prioridad/RSSI; toggle Mesh Bridge Gateway; coordinación de equipo |
| **Coordinador** | Dashboard web (VPS, pantallas grandes) | Consola de administración de incidentes; Gemelo Digital interactivo; inyección de mensajes de control |

---

## 2. El "Happy Path" — Camino Crítico por Perfil

### 2.1 Víctima: de "Listo para SOS" a ser rescatada

**Estado inicial**: escucha pasiva bajo `P2P_CLUSTER`, `ADVERTISE_MODE_LOW_POWER`, CPU en reposo profundo.

1. **Activación del SOS**: usuario presiona el botón rojo central. GPS despierta en alta precisión (`LocationManager.GPS_PROVIDER`). Pantalla muestra countdown de confirmación (~3 s) para evitar activaciones accidentales.
2. **Transmisión de alerta ("Buscando ayuda...")**: payload `BYTES` (<32 KB) con UUID, GPS, timestamp, batería residual; `startAdvertising()`; propagación multi-hop con TTL decreciente. Pantalla con animación de ondas de red, consejos de supervivencia, y acceso al triple-toque de Panic Wipe.
3. **Notificación de enlace ("Rescatista en camino")**: `acceptConnection()` tras handshake; `onPayloadReceived`/`onPayloadTransferUpdate` confirman recepción. Pantalla muestra alias de la brigada, distancia estimada (RSSI), y habilita Chat de Supervivencia.
4. **Rescate físico y cierre**: escaneo de QR o byte de control de acoplamiento; `stopAdvertising()`+`stopAllEndpoints()`. Pantalla "Rescate Completado" con recomendaciones de refugios/víveres.

### 2.2 Rescatista: de recibir una alerta a marcarla como resuelta

**Estado inicial**: `startDiscovery()` persistente bajo `P2P_CLUSTER`.

1. **Recepción de alerta**: `onEndpointFound` → `requestConnection`/`acceptConnection` → validación de UUID contra desduplicación local. Tono de alarma táctica + tarjeta flotante de incidente (prioridad, tipo, batería de la víctima, GPS).
2. **Desplazamiento y navegación offline**: "Aceptar Alerta" → estado local "En Proceso" + byte de control a la malla. Mapa de Situación Offline con ruta sobre mapas vectoriales cacheados; pin cambia de rojo a amarillo.
3. **Intercambio de datos pesados (modo híbrido)**: en rango <100 m, conmutación a `P2P_STAR`/Wi-Fi Direct para payload `FILE` (imágenes del terreno); confirmación vía `Status.SUCCESS`; apagado inmediato de Wi-Fi Direct tras completar. Pestaña "Media Recibido" con chat directo.
4. **Auxilio físico y cierre**: "Marcar Alerta como Resuelta" → estado "Resuelto"; sync a VPS si es Mesh Bridge Gateway, o inundación en malla si sigue aislado. Pin cambia a verde; bandeja se despeja para nuevo incidente.

### 2.3 Coordinador: de iniciar sesión a despachar una brigada

**Estado inicial**: login en consola web del VPS; conexión WebSocket/SSE de baja latencia.

1. **Visualización del Gemelo Digital**: mapa satelital con topología MANET en tiempo real — pines de víctimas (rojo/amarillo), brigadas (azul), líneas de conectividad.
2. **Análisis de criticidad**: sistema jerarquiza automáticamente por GPS, timestamp, batería residual y hop count. Panel muestra indicador de riesgo (ej. "Crítico - Batería al 10%").
3. **Despacho e inyección de mensajes de control**: selección de brigada disponible → "Despachar a Incidente" → directiva viaja por internet/satelital al rescatista o al gateway más cercano, que la inunda en la malla local. Pantalla de confirmación con trayectoria táctica azul en el mapa.

---

## 3. Bifurcaciones y Escenarios Alternativos

### 3.1 Víctima

- **Cancelación del SOS (countdown)**: al presionar "Cancelar" durante los 3 s, se aborta la transición; no se activa `startAdvertising` ni el GPS de alta precisión; rollback visual a "Listo para SOS".
- **Aislamiento prolongado (sin respuesta tras X minutos)**: tras un umbral parametrizable (~5 min), la app conmuta a Ciclo de Trabajo Adaptativo — BLE intermitente (`ADVERTISE_MODE_LOW_POWER`, 1000-2000 ms), GPS diferido (`setMaxUpdateDelayMillis`). UI transiciona a "Modo de Espera Eco" con brillo reducido y mensaje tranquilizador.
- **Batería crítica (<15%)**: protocolo "Faro de Último Aliento" — última fijación GPS de alta precisión, empaquetado con máxima prioridad e inundación inmediata; luego apagado de todos los receptores de alto consumo, restringiendo a balizas BLE pasivas. Pantalla de advertencia naranja instruyendo permanecer en posición.

### 3.2 Rescatista

- **Colisión de rescate (alerta ya tomada)**: la Brigada A emite payload de control al aceptar; nodos adyacentes actualizan su BD local (pin amarillo). Si la Brigada B intenta forzar la aceptación, la app bloquea el botón y muestra diálogo: *"Incidente asignado a Brigada A. ¿Desea sumarse como apoyo o seleccionar otra emergencia?"*.
- **Pérdida de conexión mesh a mitad de camino**: `onDisconnected` no borra los metadatos cacheados; estado cambia de "Tiempo Real" a "Offline - Navegación por Última Posición Conocida"; reconexión BLE automática en segundo plano al reingresar al rango de 100 m.
- **Llegada a punto GPS sin contacto visual**: botón "Iniciar Búsqueda Local (Radar)" activa `startDiscovery` con lectura adaptativa de RSSI; UI se transforma en radar de proximidad "caliente/frío"; posibilidad de abrir canal Walkie-Talkie vía Wi-Fi Direct.

### 3.3 Coordinador

- **Falta de ACK en despacho**: si el VPS no recibe confirmación criptográfica en 15 s, el estado del rescatista pasa a icono amarillo intermitente "Despacho en Cola - Transmisión por Red DTN"; la orden se inyecta en una cola de persistencia y se propaga cuando cualquier gateway recupere conectividad.
- **Desconexión del gateway a mitad de sincronización**: si `onPayloadTransferUpdate` retorna `Status.FAILURE`/`Status.CANCELED`, el VPS hace rollback de los paquetes incompletos; el móvil marca los pendientes como "No Sincronizados" en SQLite y muestra notificación discreta: *"Carga de datos interrumpida. Reintentando automáticamente al detectar conexión estable"*.

---

## 4. Estados de la Interfaz: Carga, Vacío y Errores

### 4.1 Víctima

- **GPS en Cold Start (12-15 min)**: el botón SOS se reemplaza por indicador "Buscando satélites..." con instrucción de mantenerse en espacio abierto. Durante el fix inestable inicial, se muestra un círculo de incertidumbre ("Calibrando precisión...") en lugar de coordenadas erráticas, hasta estabilizar el margen de error (<10 m).
- **Chat de Supervivencia vacío**: ilustración minimalista de ondas de radio + mensaje tranquilizador ("Tu alerta está siendo transmitida...") + lista estática de consejos de supervivencia pre-almacenados.

### 4.2 Rescatista

- **Mapa sin alertas detectadas**: mapa vectorial sin pines + banner flotante "Escaneo de Malla Activo — Buscando señales..." + mensaje central invitando a desplazarse para ampliar cobertura.
- **Error al descargar imagen (payload FILE)**: barra de progreso dinámica vía `onPayloadTransferUpdate`; ante `Status.FAILURE`/`Status.CANCELED`, la barra parpadea en rojo con texto "Descarga interrumpida: Conexión perdida" y botón "Reintentar Descarga" que renegocia el canal Wi-Fi Direct.

### 4.3 Coordinador

- **Gemelo Digital sin sincronización**: mapa satelital sin topologías dibujadas + tarjeta superpuesta "Esperando enlace dinámico con nodos pasarela. No hay datos de red ad-hoc disponibles" + panel "Sin incidentes en cola. Estado del sistema: En espera".
- **Telemetría corrupta**: el backend valida esquema/checksums antes de aceptar el paquete; si falla, se descarta y se muestra un toast discreto: "Advertencia: Descartado paquete de telemetría corrupto del dispositivo [UUID]. Conservando última posición validada".

---

## 5. Puntos de Salida y Feedback de Cierre

### 5.1 Víctima: tras "Rescate Completado"

- Pantalla "¡Estás a salvo! - Rescate Completado"; apagado de animaciones de peligro.
- Fondo: `stopAdvertising()`, `stopDiscovery()`, `stopAllEndpoints()` para congelar consumo de radio.
- Redirección a **Pantalla de Recursos de Emergencia** (estado neutro, no cierre de app): mapa offline de puntos de agua/refugios/primeros auxilios; Ficha Médica de Control offline (legible por Bluetooth/QR); botón secundario "Restablecer Estado" para reactivar escucha pasiva ante una réplica del desastre.

### 5.2 Rescatista: tras marcar "Resuelta"

- Tarjeta de éxito: "Incidente [UUID] Resuelto - Registro Guardado".
- **Reporte de cierre táctico obligatorio** (offline-first): número de víctimas atendidas, gravedad al momento del rescate, observaciones de zona.
- Transmisión: sync directo al VPS si actúa como Mesh Bridge Gateway con conectividad, o cola DTN con inundación controlada si sigue offline.
- Redirección automática al **Mapa de Situación Offline**, reactivando `startDiscovery()` bajo `P2P_CLUSTER`; pin resuelto en verde; lista para nuevas señales SOS.

### 5.3 Coordinador: tras cierre de incidente

- Pin cambia de amarillo a icono de verificación verde: "Caso Cerrado y Archivado"; timeline registra marca de tiempo de resolución.
- **Acciones secundarias invitadas**:
  1. **Generar Reporte de Desempeño** (exportar PDF/CSV): trazabilidad completa desde el primer fix GPS hasta el reporte de cierre de la brigada.
  2. **Cerrar Zona en el Gemelo Digital**: archivar el clúster geográfico si no quedan pines activos, reduciendo ruido visual.
  3. **Reasignar Recursos Estratégicos**: el sistema sugiere despachar la brigada recién liberada a incidentes adyacentes con víctimas en riesgo de batería crítica (<15%); un clic inyecta la nueva directiva vía los nodos pasarela.

---

*Documento generado a partir de la Fase de Entrevista Quirúrgica — Sección 4 del proceso PRD/TRD/PLAN/User Flow.*
