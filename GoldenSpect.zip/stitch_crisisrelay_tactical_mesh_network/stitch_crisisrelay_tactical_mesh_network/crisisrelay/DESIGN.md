---
name: CrisisRelay
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e7bdb7'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#ad8883'
  outline-variant: '#5d3f3b'
  surface-tint: '#ffb4aa'
  primary: '#ffb4aa'
  on-primary: '#690003'
  primary-container: '#ff5545'
  on-primary-container: '#5c0002'
  inverse-primary: '#c0000a'
  secondary: '#aac7ff'
  on-secondary: '#003064'
  secondary-container: '#3e90ff'
  on-secondary-container: '#002957'
  tertiary: '#53e16f'
  on-tertiary: '#003911'
  tertiary-container: '#00a741'
  on-tertiary-container: '#00320e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4aa'
  on-primary-fixed: '#410001'
  on-primary-fixed-variant: '#930005'
  secondary-fixed: '#d6e3ff'
  secondary-fixed-dim: '#aac7ff'
  on-secondary-fixed: '#001b3e'
  on-secondary-fixed-variant: '#00468d'
  tertiary-fixed: '#72fe88'
  tertiary-fixed-dim: '#53e16f'
  on-tertiary-fixed: '#002107'
  on-tertiary-fixed-variant: '#00531c'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  data-mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  data-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  touch_target_min: 48px
  margin_mobile: 16px
  gutter: 8px
  stack_sm: 4px
  stack_md: 16px
  stack_lg: 24px
---

## Brand & Style
The design system is engineered for high-stakes, low-latency environments. The brand personality is resilient, tactical, and hyper-functional, acting as a reliable digital life-line during emergencies. The visual style is a fusion of **Corporate/Modern** precision and **Brutalism-lite** clarity, prioritizing information density and speed of recognition over decorative aesthetics.

The interface must evoke a sense of calm authority and technical readiness. Every visual element serves a utility: 
- **High-Contrast:** Ensuring legibility under extreme conditions (smoke, sunlight, or low-light).
- **Tactical Utility:** Emphasizing technical data and status indicators.
- **Battery Efficiency:** Leveraging pure dark backgrounds to minimize OLED power consumption.

## Colors
The palette is optimized for immediate cognitive processing. 
- **Backgrounds:** Use `#121212` for the main canvas to ensure maximum contrast with critical UI elements.
- **Surfaces:** Use `#1E1E1E` for cards, headers, and navigation bars to provide subtle depth without compromising the dark-mode aesthetic.
- **Accents:** **Emergency Tactical Red** is reserved strictly for high-priority alerts and SOS actions. **Tactical Blue** denotes interactive elements, communication threads, and GPS data. **Emerald Green** signals "Safe" status or successful transmissions.
- **Contrast:** Maintain a minimum contrast ratio of 7:1 for all critical text against background surfaces.

## Typography
This design system employs a dual-font strategy for maximum clarity. 
- **Inter (Sans-Serif):** Used for all human-readable content, instructions, and headlines. It provides a modern, neutral, and highly legible interface.
- **JetBrains Mono (Monospace):** Used for technical telemetry, including GPS coordinates, timestamps, battery percentages, and signal strength. The monospaced nature prevents layout "jitter" as values change rapidly.
- **Accessibility:** Text size must never drop below 12px. Important status labels should use `label-caps` for immediate distinction from body text.

## Layout & Spacing
The spacing rhythm is strictly based on an **8px grid**, ensuring alignment and predictability across Android devices. 
- **Layout Model:** A fluid grid with a minimum 16px side margin on mobile. 
- **Touch Targets:** A mandatory minimum touch area of **48x48px** is enforced for all interactive elements to accommodate gloved hands or shaky environments.
- **Density:** High information density is permitted, but critical actions (SOS) must be isolated with at least 24px of clear space to prevent accidental triggers.

## Elevation & Depth
In this design system, depth is communicated through **Tonal Layering** rather than traditional shadows to maintain a flat, tactical feel.
- **Level 0 (Base):** `#121212` for the app background.
- **Level 1 (Surface):** `#1E1E1E` for primary content containers and cards.
- **Level 2 (Active):** Higher luminosity grey or subtle 1px inner-strokes (0.1 opacity white) to indicate pressed states or active fields.
- **Outlines:** Use low-contrast 1px borders (`#333333`) to define boundaries between adjacent surface elements without introducing visual noise.

## Shapes
The shape language is "Calculated Softness."
- **Cards & Containers:** 12px corner radius (`rounded-lg`) provides a modern, professional feel that fits the Android ecosystem.
- **Action Elements:** Buttons and interactive pills use a **999px (Pill)** radius. This distinct shape makes buttons immediately identifiable as interactive compared to static content cards.
- **Inputs:** 8px radius to differentiate from primary action buttons.

## Components
### Buttons
- **Primary SOS:** Full-width, Emergency Red background, white text. Mandatory 999px radius. Height: 56px.
- **Secondary Action:** Tactical Blue background or outline. Height: 48px.
- **Ghost Actions:** Transparent background with white or blue border for non-critical navigation.

### Data Chips
Small, 999px radius pills using `data-mono-sm` typography. Backgrounds should be low-opacity versions of the accent colors (e.g., 15% Blue for "GPS Active").

### Input Fields
Filled style using the Surface color (`#1E1E1E`). 1px bottom stroke or full border on focus using Tactical Blue. Placeholders must be high-contrast (`#A0A0A0`).

### Status Cards
Containers for telemetry. 12px radius. Use a vertical 4px accent bar on the left edge of the card to indicate status color (Red/Blue/Green) without overwhelming the card background.

### Navigation
Bottom Navigation Bar following Material 3 guidelines: `#1E1E1E` background, active state highlighted with a Tactical Blue indicator pill.